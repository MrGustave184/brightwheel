
  (function ($) {

    $(document).ready(function () { 
        $("#accordion-panel-woocommerce > h3").append("<span class='new'>NEW</span>");
    });    

})(this.jQuery);